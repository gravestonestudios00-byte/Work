# Orbit Foundry: Phone-only cloud APK build

This project is source code. To install it on your phone without a PC, build it in GitHub Actions and download the APK.

## 1. Upload the project to GitHub from your phone

1. Install the GitHub app or open GitHub in your browser.
2. Create a new repository named `OrbitFoundry`.
3. Upload all files and folders from this project, including `.github/workflows/build-apk.yml`.

## 2. Run the APK build

1. Open the repository on GitHub.
2. Go to **Actions**.
3. Select **Build Android APK**.
4. Tap **Run workflow**.
5. Wait for the run to finish.

## 3. Download the APK

1. Open the completed workflow run.
2. Scroll to **Artifacts**.
3. Download **OrbitFoundry-debug-apk**.
4. Unzip it on your phone.
5. Install `app-debug.apk`.

## 4. Allow APK install on Android

If Android blocks it:

1. Open **Settings**.
2. Search **Install unknown apps**.
3. Allow your browser or file manager to install unknown apps.
4. Tap the APK again.

## Notes

- The APK is a debug build, so Android may warn you before installing.
- This is normal for apps built outside the Play Store.
- Every time you edit the code and push/upload changes to GitHub, GitHub Actions can build a fresh APK.
